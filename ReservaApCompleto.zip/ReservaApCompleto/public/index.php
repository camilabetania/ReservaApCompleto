<?php
// Redirecionamento relativo que funciona em qualquer ambiente
header("Location: pages/index.php");
exit;